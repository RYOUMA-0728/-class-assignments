using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using App_development_all.Data;
using App_development_all.Models;
using System.Linq;

namespace App_development_all.Pages.Carrier
{
    public class LoginModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public LoginModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public string Username { get; set; }

        [BindProperty]
        public string Password { get; set; }

        public string ErrorMessage { get; set; }

        public IActionResult OnPost()
        {
            var username = Username?.Trim();
            var password = Password?.Trim();

            var carrier = _context.Carriers
                .FirstOrDefault(c =>
                    c.Name == username &&
                    c.Password == password
                );

            if (carrier == null)
            {
                ErrorMessage = "��Ж��܂��̓p�X���[�h���Ⴂ�܂�";
                return Page();
            }

            return RedirectToPage("/Carrier/Index");
        }
    }
}
