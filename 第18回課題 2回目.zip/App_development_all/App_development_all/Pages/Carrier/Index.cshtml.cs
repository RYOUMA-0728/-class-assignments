using App_development_all.Data;
using App_development_all.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace App_development_all.Pages.Carrier
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<PackageMaster> PackageList { get; set; } = new();

        [BindProperty]
        public int MasterId { get; set; }

        public void OnGet()
        {
            PackageList = _context.PackageMasters
                .Include(p => p.RequesterData)
                    .ThenInclude(r => r.Customer)
                .Include(p => p.DestinationData)
                .Include(p => p.DeliveryStatus)
                .Include(p => p.Carrier)
                .OrderByDescending(p => p.CreatedAt)
                .ToList();
        }

        // ===== �������蓖�� =====
        public IActionResult OnPostAutoAssign()
        {
            var package = _context.PackageMasters
                .FirstOrDefault(p => p.MasterId == MasterId);

            if (package == null)
            {
                return NotFound();
            }

            // �z�B����1�l�擾�i�ŏ����W�b�N�j
            var carrier = _context.Carriers
                .OrderBy(c => c.Id)
                .FirstOrDefault();

            if (carrier == null)
            {
                return Page();
            }

            package.CarrierId = carrier.Id;

            // �X�e�[�^�X���u�W�ג��v�ɕύX�i��F2�j
            package.StatusId = 2;

            _context.SaveChanges();

            return RedirectToPage();
        }

        // ===== ���O�A�E�g =====
        public IActionResult OnPostLogout()
        {
            // �F�ؓ�����Ɏ���
            return RedirectToPage("/Carrier/Login");
        }
    }
}
