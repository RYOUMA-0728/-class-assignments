using Microsoft.AspNetCore.Mvc.RazorPages;

namespace App_development_all.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
