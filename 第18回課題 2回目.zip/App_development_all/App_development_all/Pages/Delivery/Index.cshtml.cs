using App_development_all.Data;
using App_development_all.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace App_development_all.Pages.Delivery
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;


        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        // �z���ꗗ
        public List<PackageMaster> PackageList { get; set; } = new();
        public List<DeliveryStatus> StatusList { get; set; } = new();
        public void OnGet()
        {
            PackageList = _context.PackageMasters
                .Include(p => p.RequesterData)
                    .ThenInclude(r => r.Customer)
                .Include(p => p.DestinationData)
                .Include(p => p.DeliveryStatus)
                .OrderByDescending(p => p.CreatedAt)
                .ToList();

            StatusList = _context.DeliveryStatuses
                .OrderBy(s => s.StatusId)
                .ToList();
        }

        [BindProperty]
        public int MasterId { get; set; }

        [BindProperty]
        public int StatusId { get; set; }

        public IActionResult OnPostUpdateStatus()
        {
            var package = _context.PackageMasters
                .FirstOrDefault(p => p.MasterId == MasterId);

            if (package == null)
            {
                return NotFound();
            }

            package.StatusId = StatusId;
            _context.SaveChanges();

            return RedirectToPage();
        }
        public IActionResult OnPostLogout()
        {
            HttpContext.Session.Clear();
            return RedirectToPage("/Delivery/Login");
        }
    }
}
