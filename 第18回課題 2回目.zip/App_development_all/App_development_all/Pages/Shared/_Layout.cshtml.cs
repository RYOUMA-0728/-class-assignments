using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace App_development_all.Pages.Shared
{
    public class _LayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
