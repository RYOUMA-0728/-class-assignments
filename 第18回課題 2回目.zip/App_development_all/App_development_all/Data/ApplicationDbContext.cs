﻿using App_development_all.Models;
using Microsoft.EntityFrameworkCore;

namespace App_development_all.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Delivery> Deliveries { get; set; }
        public DbSet<Carrier> Carriers { get; set; }

        public DbSet<RequesterData> RequesterDatas { get; set; }
        public DbSet<DestinationData> DestinationDatas { get; set; }
        public DbSet<DeliveryStatus> DeliveryStatuses { get; set; }
        public DbSet<PackageMaster> PackageMasters { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // package_master
            modelBuilder.Entity<PackageMaster>()
                .ToTable("package_master")
                .HasOne(p => p.RequesterData)
                .WithMany()
                .HasForeignKey(p => p.RequesterId);

            modelBuilder.Entity<PackageMaster>()
                .HasOne(p => p.DestinationData)
                .WithMany()
                .HasForeignKey(p => p.DestinationId);

            modelBuilder.Entity<PackageMaster>()
                .HasOne(p => p.DeliveryStatus)
                .WithMany()
                .HasForeignKey(p => p.StatusId);

            // requester_data
            modelBuilder.Entity<RequesterData>()
                .ToTable("requester_data");

            // destination_data
            modelBuilder.Entity<DestinationData>()
                .ToTable("destination_data");

            // delivery_status
            modelBuilder.Entity<DeliveryStatus>()
                .ToTable("delivery_status");
        }
    }
}