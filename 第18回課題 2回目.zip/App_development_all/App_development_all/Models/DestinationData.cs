﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace App_development_all.Models
{
    [Table("destination_data")]
    public class DestinationData
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("name")]
        public string Name { get; set; }

        [Column("kana")]
        public string Kana { get; set; }

        [Column("postal_code")]
        public string PostalCode { get; set; }

        [Column("address")]
        public string Address { get; set; }

        [Column("delivery_date")]
        public DateTime? DeliveryDate { get; set; }

        [Column("delivery_time")]
        public string? DeliveryTime { get; set; }
    }
}
