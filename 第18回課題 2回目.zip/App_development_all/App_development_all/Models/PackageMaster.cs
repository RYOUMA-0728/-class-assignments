﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace App_development_all.Models
{
    [Table("package_master")]
    public class PackageMaster
    {
        [Key]
        [Column("master_id")]
        public int MasterId { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; }

        // ★ 配送ステータス
        [Column("status_id")]
        public int StatusId { get; set; }
        public DeliveryStatus DeliveryStatus { get; set; }

        // ★ 依頼者
        [Column("requester_id")]
        public int RequesterId { get; set; }
        public RequesterData RequesterData { get; set; }

        // ★ 配送先
        [Column("destination_id")]
        public int DestinationId { get; set; }
        public DestinationData DestinationData { get; set; }

        // ★ 追加
        [Column("carrier_id")]
        public int? CarrierId { get; set; }
        public Carrier? Carrier { get; set; }
    }
}
