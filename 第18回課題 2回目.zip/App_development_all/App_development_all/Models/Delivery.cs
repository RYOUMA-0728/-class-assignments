﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace App_development_all.Models
{
    [Table("delivery")]
    public class Delivery
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("name")]
        public string Name { get; set; }

        [Column("kana")]
        public string Kana { get; set; }

        [Column("birth_date")]
        public DateTime? BirthDate { get; set; }

        [Column("password")]
        public string Password { get; set; }

        [Column("postal_code")]
        public string PostalCode { get; set; }

        [Column("address")]
        public string Address { get; set; }
    }
}
