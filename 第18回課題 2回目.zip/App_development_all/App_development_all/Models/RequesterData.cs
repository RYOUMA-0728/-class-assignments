﻿using App_development_all.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace App_development_all.Models
{
    [Table("requester_data")]
    public class RequesterData
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("customer_id")]
        public int CustomerId { get; set; }

        [ForeignKey(nameof(CustomerId))]
        public Customer Customer { get; set; }

        // ★ 追加: package_type カラム
        [Column("package_type")]
        public string? PackageType { get; set; }

        [Column("quantity")]
        public int Quantity { get; set; }
    }
}